﻿//#include <iostream>
//#include<windows.h>
//
//using namespace std;
//
//int main()
//{
//    SetConsoleCP(1251);
//    SetConsoleOutputCP(1251);
//
//    //switch
//    //    1. Дано країна.Вивести назву столиці. (5 countries)
//    
//    //enum country{ukraine = 1, france = 2, japan = 3, brazil = 4, australia = 5};
//    //int capital;
//
//    //cout << "Виберіть країну:" << endl;
//    //cout << "1. Ukraine" << endl;
//    //cout << "2. France" << endl;
//    //cout << "3. Japan" << endl;
//    //cout << "4. Brazil" << endl;
//    //cout << "5. Australia" << endl;
//    //cout << "Зробіть свій вибір: ";
//    //cin >> capital;
//
//    //switch (capital)
//    //{
//    //case 1:
//    //    cout << "Kyiv";
//    //    break;
//    //case 2:
//    //    cout << "Paris";
//    //    break;
//    //case 3:
//    //    cout << "Tokyo";
//    //    break;
//    //case 4:
//    //    cout << "Brasilia";
//    //    break;
//    //case 5:
//    //    cout << "Canberra";
//    //    break;
//    //default:
//    //    break;
//    //}
//
//    
//    //    2.Дано номер дня тижня(1 – понеділок і т.д.).Визначити чи це вихідний день.
//    
//    //enum week{Monday = 1, Tuesday = 2, Wednesday = 3, Thursday = 4, Friday = 5, Saturday = 6, Sunday = 7};
//    //int day;
//    //cout << "Який вас день цікавить?(1-7): ";
//    //cin >> day;
//
//    //switch (day)
//    //{
//    //case 1:
//    //    cout << "Це робочий будень";
//    //    break;
//    //case 2:
//    //    cout << "Це робочий будень";
//    //    break;
//    //case 3:
//    //    cout << "Це робочий будень";
//    //    break;
//    //case 4:
//    //    cout << "Це робочий будень";
//    //    break;
//    //case 5:
//    //    cout << "Це робочий будень, завтра вихідний)))";
//    //    break;
//    //case 6:
//    //    cout << "ВИХІДНИЙ!!!!)";
//    //    break;
//    //case 7:
//    //    cout << "ВИХІДНИЙ!!!!)";
//    //    break;
//    //default:
//    //    break;
//    //}
//    //    3.Дано курс корабля(північ, південь, захід, схід).Як
//    //    зміниться курс корабля після команди «назад» ?
//    
//    //enum orientation { північ = 1, південь = 2, захід = 3, схід = 4};
//    //int orientation;
//    //cout << "В якому напрямку курсує кораблик?" << endl;
//    //cout << "1. північ;" << endl;
//    //cout << "2. південь;" << endl;
//    //cout << "3. захід;" << endl;
//    //cout << "4. схід;" << endl;
//    //cout << "Зробіть свій вибір: ";
//    //cin >> orientation;
//
//    //switch (orientation)
//    //{
//    //case 1:
//    //    cout << "Кораблик змінить курс на південь!";
//    //    break;
//    //case 2:
//    //    cout << "Кораблик змінить курс на північ!";
//    //    break;
//    //case 3:
//    //    cout << "Кораблик змінить курс на схід!";
//    //    break;
//    //case 4:
//    //    cout << "Кораблик змінить курс на захід!";
//    //    break;
//    //default:
//    //    break;
//    //}
//    
//    //    4.Дано тварина(номер тварини. 1 – жираф. 2 – орел.тощо). (7 animals)
//    //    Вивести клас, до якого відноситься тварина(хижак, травоїдна).
//
//    enum animals {
//        Giraffe = 1, Eagle = 2, Tiger = 3, Rabbit = 4, Lion = 5, Deer = 6, Horse = 7
//    };
//    int animal;
//    cout << "Вибери тварину?" << endl;
//    cout << "1. Giraffe;" << endl;
//    cout << "2. Eagle;" << endl;
//    cout << "3. Tiger;" << endl;
//    cout << "4. Rabbit;" << endl;
//    cout << "5. Lion;" << endl;
//    cout << "6. Deer;" << endl;
//    cout << "7. Horse;" << endl;
//    cout << "Зробіть свій вибір: ";
//    cin >> animal;
//
//    switch (animal)
//    {
//    case 1:
//        cout << "Ця тварина Herbivore!";
//        break;
//    case 2:
//        cout << "Ця тварина Predator!";
//        break;
//    case 3:
//        cout << "Ця тварина Predator!";
//        break;
//    case 4:
//        cout << "Ця тварина Herbivore!";
//        break;
//    case 5:
//        cout << "Ця тварина Predator!";
//        break;
//    case 6:
//        cout << "Ця тварина Herbivore!";
//        break;
//    case 7:
//        cout << "Ця тварина Herbivore!";
//        break;
//    default:
//        break;
//    }
//
//
//
//
//
//
//}
